package com.example.program3;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        EditText number1=findViewById(R.id.n1);
        EditText number2=findViewById(R.id.n2);
        Button b1=findViewById(R.id.add);
        Button b2=findViewById(R.id.sub);
        Button b3=findViewById(R.id.mul);
        Button b4=findViewById(R.id.div);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                float a=Float.parseFloat(number1.getText().toString());
                float b=Float.parseFloat(number2.getText().toString());
                float sol=a+b;
                Toast.makeText(MainActivity.this, "The sum is "+sol, Toast.LENGTH_LONG).show();
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                float a=Float.parseFloat(number1.getText().toString());
                float b=Float.parseFloat(number2.getText().toString());
                float sol=a-b;
                Toast.makeText(MainActivity.this, "The difference is "+sol, Toast.LENGTH_LONG).show();
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                float a=Float.parseFloat(number1.getText().toString());
                float b=Float.parseFloat(number2.getText().toString());
                float sol=a*b;
                Toast.makeText(MainActivity.this, "Multiply "+sol, Toast.LENGTH_LONG).show();
            }
        });
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                float a=Float.parseFloat(number1.getText().toString());
                float b=Float.parseFloat(number2.getText().toString());
                float sol=a/b;
                Toast.makeText(MainActivity.this, "Division "+sol, Toast.LENGTH_LONG).show();
            }
        });

    }
}