package com.example.program6;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    EditText editText;
    Button b1, b2, b3, b4, b5, b6, b7, b8, b9, b0, plus, sub, mul, div, eq, ac;
    float value1, value2;
    Boolean addition = false, subtraction = false, multiplication = false, division = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editText = findViewById(R.id.editText);
        b1 = findViewById(R.id.button1);
        b2 = findViewById(R.id.button2);
        b3 = findViewById(R.id.button3);
        b4 = findViewById(R.id.button4);
        b5 = findViewById(R.id.button5);
        b6 = findViewById(R.id.button6);
        b7 = findViewById(R.id.button7);
        b8 = findViewById(R.id.button8);
        b9 = findViewById(R.id.button9);
        b0 = findViewById(R.id.button0);
        plus = findViewById(R.id.adds);
        sub = findViewById(R.id.subs);
        mul = findViewById(R.id.muls);
        div = findViewById(R.id.divs);
        eq = findViewById(R.id.eql);
        ac = findViewById(R.id.acl);

        // Number buttons
        b1.setOnClickListener(v -> editText.setText(editText.getText() + "1"));
        b2.setOnClickListener(v -> editText.setText(editText.getText() + "2"));
        b3.setOnClickListener(v -> editText.setText(editText.getText() + "3"));
        b4.setOnClickListener(v -> editText.setText(editText.getText() + "4"));
        b5.setOnClickListener(v -> editText.setText(editText.getText() + "5"));
        b6.setOnClickListener(v -> editText.setText(editText.getText() + "6"));
        b7.setOnClickListener(v -> editText.setText(editText.getText() + "7"));
        b8.setOnClickListener(v -> editText.setText(editText.getText() + "8"));
        b9.setOnClickListener(v -> editText.setText(editText.getText() + "9"));
        b0.setOnClickListener(v -> editText.setText(editText.getText() + "0"));

        // Operator buttons
        plus.setOnClickListener(v -> {
            value1 = Float.parseFloat(editText.getText().toString());
            addition = true;
            editText.setText(null);
        });

        sub.setOnClickListener(v -> {
            value1 = Float.parseFloat(editText.getText().toString());
            subtraction = true;
            editText.setText(null);
        });

        mul.setOnClickListener(v -> {
            value1 = Float.parseFloat(editText.getText().toString());
            multiplication = true;
            editText.setText(null);
        });

        div.setOnClickListener(v -> {
            value1 = Float.parseFloat(editText.getText().toString());
            division = true;
            editText.setText(null);
        });

        // Equal button
        eq.setOnClickListener(v -> {
            value2 = Float.parseFloat(editText.getText().toString());

            if (addition) {
                editText.setText(value1 + value2 + "");
                addition = false;
            }

            if (subtraction) {
                editText.setText(value1 - value2 + "");
                subtraction = false;
            }

            if (multiplication) {
                editText.setText(value1 * value2 + "");
                multiplication = false;
            }

            if (division) {
                editText.setText(value1 / value2 + "");
                division = false;
            }
        });

        // AC button
        ac.setOnClickListener(v -> editText.setText(""));
    }
}
